(function () {
  "use strict";

  function $(selector) { return document.querySelector(selector); }
  function $$(selector) { return Array.prototype.slice.call(document.querySelectorAll(selector)); }

  var memoryStore = {};
  function showStorageNotice() {
    var notice = $("#storageNotice");
    if (notice) notice.hidden = false;
  }
  var store = {
    get: function (key) {
      if (Object.prototype.hasOwnProperty.call(memoryStore, key)) return memoryStore[key];
      try { return localStorage.getItem(key); } catch (e) { showStorageNotice(); return null; }
    },
    set: function (key, value) {
      memoryStore[key] = value;
      try { localStorage.setItem(key, value); } catch (e) { showStorageNotice(); }
    }
  };

  var KEYS = {
    theme: "luna-present-theme",
    kanban: "luna-present-kanban-v1",
    checklist: "luna-present-checklist-v1",
    guide: "luna-launchpad-guide-v1",
    supporter: "luna-first-pack-name-v1"
  };

  var toastTimer;
  function toast(message) {
    var el = $("#toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove("show"); }, 1800);
  }

  function copyText(text) {
    if (!text || !String(text).trim()) {
      toast("There is nothing to copy yet.");
      return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        toast("Copied to your clipboard.");
      }).catch(function () {
        fallbackCopy(text);
      });
    } else {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    var previousFocus = document.activeElement;
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    var copied = false;
    try { copied = document.execCommand("copy"); } catch (e) {}
    ta.remove();
    if (previousFocus && previousFocus.focus) previousFocus.focus();
    toast(copied ? "Copied to your clipboard." : "Clipboard unavailable. Select the text and copy it manually.");
  }

  var savedTheme = store.get(KEYS.theme);
  function useTheme(theme) {
    if (["dark", "light", "aurora"].indexOf(theme) === -1) theme = "dark";
    document.documentElement.dataset.theme = theme;
    store.set(KEYS.theme, theme);
    $$("[data-theme-choice]").forEach(function (button) {
      button.setAttribute("aria-pressed", String(button.dataset.themeChoice === theme));
    });
    var labels = {dark:"Midnight",light:"Daybreak",aurora:"Luna Aurora"};
    $("#themeToggle").setAttribute("aria-label", "Switch color theme. Current theme: " + labels[theme]);
    var meta = $("meta[name='theme-color']");
    if (meta) meta.content = theme === "light" ? "#f4f7fb" : theme === "aurora" ? "#141222" : "#0b0f16";
    $("#themeToggle").title = "Current theme: " + labels[theme] + ". Activate to switch.";
  }
  useTheme(savedTheme || "dark");
  $("#themeToggle").addEventListener("click", function () {
    var choices = ["dark", "light", "aurora"];
    var current = document.documentElement.dataset.theme || "dark";
    useTheme(choices[(choices.indexOf(current) + 1) % choices.length]);
  });
  $$("[data-theme-choice]").forEach(function (button) {
    button.addEventListener("click", function () { useTheme(button.dataset.themeChoice); });
  });

  var promptPresets = {
    learn: {
      role: "a patient learning coach",
      goal: "Explain this topic so I can really understand it.",
      context: "I am a beginner and know the basics.",
      rules: "Use plain language. Explain new terms. Break big steps into small ones.",
      output: "A short explanation, a worked example, and three practice questions with answers."
    },
    code: {
      role: "a friendly senior developer and mentor",
      goal: "Help me build a small working solution.",
      context: "I am still learning and want to understand why each step is needed.",
      rules: "Avoid unnecessary dependencies. Choose safe defaults. Explain likely errors.",
      output: "A step-by-step plan, code, a test guide, and common mistakes."
    },
    plan: {
      role: "a practical project mentor",
      goal: "Turn my idea into a small, achievable first project.",
      context: "The project should grow one small step at a time.",
      rules: "Start with an MVP. Prioritize clarity over the number of features.",
      output: "The MVP goal, five to seven tasks, a definition of done, and three future ideas."
    }
  };

  $$(".prompt-preset").forEach(function (button) {
    button.addEventListener("click", function () {
      var p = promptPresets[button.dataset.preset];
      $("#promptRole").value = p.role;
      $("#promptGoal").value = p.goal;
      $("#promptContext").value = p.context;
      $("#promptRules").value = p.rules;
      $("#promptOutput").value = p.output;
      toast("Starter prompt added.");
    });
  });

  function buildPrompt() {
    var values = [
      ["Role", $("#promptRole").value.trim()],
      ["Goal", $("#promptGoal").value.trim()],
      ["Context", $("#promptContext").value.trim()],
      ["Rules / limits", $("#promptRules").value.trim()],
      ["Desired output", $("#promptOutput").value.trim()]
    ];
    var parts = [];
    values.forEach(function (item) {
      if (item[1]) parts.push(item[0] + ":\n" + item[1]);
    });
    $("#promptResult").textContent = parts.length ? parts.join("\n\n") : "Fill in at least one field.";
  }
  $("#buildPrompt").addEventListener("click", buildPrompt);
  $("#copyPrompt").addEventListener("click", function () { copyText($("#promptResult").textContent); });

  var commands = [
    { type:"linux", cmd:"pwd", note:"Show your current folder." },
    { type:"linux", cmd:"ls -la", note:"List files, including hidden entries." },
    { type:"linux", cmd:"cd <folder>", note:"Move to a folder. Replace <folder> with its name." },
    { type:"linux", cmd:"mkdir <name>", note:"Create a new folder." },
    { type:"windows", cmd:"Get-Location", note:"Show your current folder in PowerShell." },
    { type:"windows", cmd:"Get-ChildItem", note:"List files and folders." },
    { type:"windows", cmd:"Set-Location <folder>", note:"Move to a folder." },
    { type:"windows", cmd:"New-Item -ItemType Directory <name>", note:"Create a new folder." },
    { type:"git", cmd:"git status", note:"See which files you have changed." },
    { type:"git", cmd:"git diff", note:"Inspect changes that are not committed yet." },
    { type:"git", cmd:"git log --oneline -5", note:"See the five most recent commits." },
    { type:"git", cmd:"git branch", note:"List local branches; the current one is marked." },
    { type:"git", cmd:"git add <file>", note:"Stage a file for the next commit." },
    { type:"git", cmd:"git commit -m \"short message\"", note:"Save a local commit with a short description." },
    { type:"git", cmd:"git push", note:"Publish local commits to the configured remote." }
  ];

  function makeCopyButton(text, label) {
    var button = document.createElement("button");
    button.className = "copy-mini";
    button.type = "button";
    button.textContent = "Copy";
    button.setAttribute("aria-label", label || "Copy text");
    button.addEventListener("click", function () { copyText(text); });
    return button;
  }

  function renderCommands() {
    var filter = $("#commandFilter").value;
    var box = $("#commandList");
    box.textContent = "";
    commands.filter(function (c) {
      return filter === "all" || c.type === filter;
    }).forEach(function (c) {
      var item = document.createElement("div");
      item.className = "command-item";
      var copy = document.createElement("div");
      var code = document.createElement("code");
      var note = document.createElement("small");
      code.textContent = c.cmd;
      note.textContent = c.note;
      copy.appendChild(code);
      copy.appendChild(note);
      item.appendChild(copy);
      item.appendChild(makeCopyButton(c.cmd, "Copy command " + c.cmd));
      box.appendChild(item);
    });
  }
  $("#commandFilter").addEventListener("change", renderCommands);
  renderCommands();

  function emailDE(purpose, name, point) {
    var hello = "Hallo " + (name || "zusammen") + ",\n\n";
    var close = "\n\nFreundliche Grüße\n[Dein Name]";
    if (purpose === "question") return hello + "ich habe eine kurze Frage: " + (point || "[Kernpunkt ergänzen]") + ".\n\nKönnten Sie mir dazu bitte kurz weiterhelfen?\n\nVielen Dank." + close;
    if (purpose === "feedback") return hello + "ich möchte kurz Feedback geben: " + (point || "[Kernpunkt ergänzen]") + ".\n\nIch hoffe, das hilft für die nächsten Schritte." + close;
    if (purpose === "meeting") return hello + "ich würde gern einen kurzen Termin abstimmen. Thema: " + (point || "[Thema ergänzen]") + ".\n\nWelche Zeit passt Ihnen in den nächsten Tagen gut?" + close;
    return hello + "vielen Dank für " + (point || "[Grund ergänzen]") + ". Das hat mir sehr geholfen." + close;
  }

  function emailEN(purpose, name, point) {
    var hello = "Hello " + (name || "there") + ",\n\n";
    var close = "\n\nBest regards,\n[Your name]";
    if (purpose === "question") return hello + "I have a quick question: " + (point || "[add the key point]") + ".\n\nCould you please help me with this?\n\nThank you." + close;
    if (purpose === "feedback") return hello + "I wanted to share a quick piece of feedback: " + (point || "[add the key point]") + ".\n\nI hope this is useful for the next steps." + close;
    if (purpose === "meeting") return hello + "I would like to arrange a short meeting about " + (point || "[add the topic]") + ".\n\nWhat time would work well for you in the next few days?" + close;
    return hello + "Thank you for " + (point || "[add the reason]") + ". It was very helpful." + close;
  }

  $("#buildEmail").addEventListener("click", function () {
    var lang = $("#emailLang").value;
    var purpose = $("#emailPurpose").value;
    var name = $("#emailName").value.trim();
    var point = $("#emailPoint").value.trim();
    $("#emailResult").textContent = lang === "de" ? emailDE(purpose, name, point) : emailEN(purpose, name, point);
  });
  $("#copyEmail").addEventListener("click", function () { copyText($("#emailResult").textContent); });

  var defaultBoard = { todo:[{id:"sample-1",text:"Choose one small idea"}], doing:[], done:[] };
  var columns = [
    {id:"todo",title:"To do"},
    {id:"doing",title:"Doing"},
    {id:"done",title:"Done"}
  ];

  function cloneDefaultBoard() { return JSON.parse(JSON.stringify(defaultBoard)); }
  function loadBoard() {
    try {
      var parsed = JSON.parse(store.get(KEYS.kanban));
      var valid = parsed && columns.every(function (column) {
        return Array.isArray(parsed[column.id]) && parsed[column.id].every(function (task) {
          return task && typeof task.text === "string" && task.text.trim().length > 0 && task.text.length <= 100
            && (typeof task.id === "string" || typeof task.id === "number");
        });
      });
      return valid ? parsed : cloneDefaultBoard();
    } catch (e) { return cloneDefaultBoard(); }
  }
  var board = loadBoard();
  function saveBoard() { store.set(KEYS.kanban, JSON.stringify(board)); }

  function moveTask(from, index, direction) {
    var colIndex = columns.findIndex(function (c) { return c.id === from; });
    var targetIndex = colIndex + direction;
    if (targetIndex < 0 || targetIndex >= columns.length) return;
    var task = board[from].splice(index, 1)[0];
    board[columns[targetIndex].id].push(task);
    saveBoard();
    renderBoard();
    var movedCard = $$(".task-card").filter(function (card) { return card.dataset.taskId === String(task.id); })[0];
    if (movedCard) {
      var action = movedCard.querySelector("button:not(:disabled)");
      if (action) action.focus();
    }
  }

  function removeTask(from, index) {
    board[from].splice(index, 1);
    saveBoard();
    renderBoard();
    $("#taskInput").focus();
  }

  function taskButton(label, title, handler, disabled, className) {
    var button = document.createElement("button");
    button.type = "button";
    button.textContent = label;
    button.setAttribute("aria-label", title);
    if (disabled) button.disabled = true;
    if (className) button.className = className;
    button.addEventListener("click", handler);
    return button;
  }

  function renderBoard() {
    var root = $("#kanbanBoard");
    root.textContent = "";
    columns.forEach(function (col, colIndex) {
      var section = document.createElement("section");
      section.className = "kanban-column";
      section.setAttribute("aria-label", col.title);

      var head = document.createElement("div");
      head.className = "column-head";
      var title = document.createElement("h4");
      title.textContent = col.title;
      var count = document.createElement("span");
      count.className = "column-count";
      count.textContent = board[col.id].length;
      head.appendChild(title);
      head.appendChild(count);
      section.appendChild(head);

      if (!board[col.id].length) {
        var empty = document.createElement("small");
        empty.className = "column-count";
        empty.textContent = "Nothing here yet.";
        section.appendChild(empty);
      }

      board[col.id].forEach(function (task, taskIndex) {
        var card = document.createElement("div");
        card.className = "task-card";
        card.dataset.taskId = String(task.id);
        var p = document.createElement("p");
        p.textContent = task.text;
        var actions = document.createElement("div");
        actions.className = "task-actions";
        actions.appendChild(taskButton("←", "Move task left", function () { moveTask(col.id, taskIndex, -1); }, colIndex === 0));
        actions.appendChild(taskButton("→", "Move task right", function () { moveTask(col.id, taskIndex, 1); }, colIndex === columns.length - 1));
        actions.appendChild(taskButton("×", "Remove task", function () { removeTask(col.id, taskIndex); }, false, "remove"));
        card.appendChild(p);
        card.appendChild(actions);
        section.appendChild(card);
      });
      root.appendChild(section);
    });
  }

  $("#taskInput").addEventListener("input", function () { this.setCustomValidity(""); });
  $("#taskForm").addEventListener("submit", function (event) {
    event.preventDefault();
    var input = $("#taskInput");
    var text = input.value.trim();
    if (!text) {
      input.setCustomValidity("Write a task, not just spaces.");
      input.reportValidity();
      return;
    }
    var col = $("#taskColumn").value;
    board[col].push({id:Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8),text:text});
    input.value = "";
    saveBoard();
    renderBoard();
    input.focus();
  });

  $("#resetKanban").addEventListener("click", function () {
    var hasTasks = columns.some(function (column) { return board[column.id].length > 0; });
    if (hasTasks && !window.confirm("Reset this board? Your saved tasks will be replaced by the starter task.")) return;
    board = cloneDefaultBoard();
    saveBoard();
    renderBoard();
    toast("Board reset.");
  });
  renderBoard();

  function parseJson() {
    var raw = $("#jsonInput").value.trim();
    if (!raw) throw new Error("Paste some JSON first.");
    return JSON.parse(raw);
  }
  function setJsonStatus(message, type) {
    var status = $("#jsonStatus");
    status.textContent = message;
    status.className = "status " + (type || "");
  }
  $("#formatJson").addEventListener("click", function () {
    try {
      $("#jsonInput").value = JSON.stringify(parseJson(), null, 2);
      setJsonStatus("Valid JSON — formatted.", "ok");
    } catch (e) { setJsonStatus("Error: " + e.message, "error"); }
  });
  $("#minifyJson").addEventListener("click", function () {
    try {
      $("#jsonInput").value = JSON.stringify(parseJson());
      setJsonStatus("Valid JSON — minified.", "ok");
    } catch (e) { setJsonStatus("Error: " + e.message, "error"); }
  });
  $("#copyJson").addEventListener("click", function () { copyText($("#jsonInput").value); });

  var checklistItems = [
    ["Choose one small idea","One problem or feature is enough for a first version."],
    ["Write the README goal","In two or three sentences: what is it, who is it for, and how does it start?"],
    ["Build the smallest working version","One finished thing is better than five half-built features."],
    ["Check your Git status","Use git status to see the changes you actually made."],
    ["Make your first clear commit","Use a short message that describes the change."],
    ["Try it as a new user","Start the project in the way you plan to show it."],
    ["Write down the next small step","One clear task helps keep a project on track."]
  ];

  function loadChecklist() {
    try {
      var parsed = JSON.parse(store.get(KEYS.checklist));
      return Array.isArray(parsed) && parsed.length === checklistItems.length && parsed.every(function (value) { return typeof value === "boolean"; })
        ? parsed : checklistItems.map(function () { return false; });
    } catch (e) { return checklistItems.map(function () { return false; }); }
  }
  var checklistState = loadChecklist();

  function saveChecklist() { store.set(KEYS.checklist, JSON.stringify(checklistState)); }
  function updateChecklistProgress() {
    var done = checklistState.filter(Boolean).length;
    $("#checkProgress").textContent = done + " of " + checklistItems.length + " complete";
    $("#checkProgressBar").style.width = ((done / checklistItems.length) * 100) + "%";
  }

  function renderChecklist() {
    var root = $("#projectChecklist");
    root.textContent = "";
    checklistItems.forEach(function (item, index) {
      var label = document.createElement("label");
      label.className = "check-row";
      var input = document.createElement("input");
      input.type = "checkbox";
      input.checked = checklistState[index];
      var span = document.createElement("span");
      var strong = document.createElement("strong");
      var small = document.createElement("small");
      strong.textContent = item[0];
      small.textContent = item[1];
      span.appendChild(strong);
      span.appendChild(small);
      label.appendChild(input);
      label.appendChild(span);
      input.addEventListener("change", function () {
        checklistState[index] = input.checked;
        saveChecklist();
        updateChecklistProgress();
      });
      root.appendChild(label);
    });
    updateChecklistProgress();
  }

  $("#resetChecklist").addEventListener("click", function () {
    if (checklistState.some(Boolean) && !window.confirm("Reset your checklist? Your saved progress will be cleared.")) return;
    checklistState = checklistItems.map(function () { return false; });
    saveChecklist();
    renderChecklist();
    toast("Checklist reset.");
  });
  renderChecklist();

  var missions = [
    ["BEGINNER","Build an HTML page with a heading, a paragraph, and a button. Make the button change the text."],
    ["BEGINNER","Make three Git commits for three small changes, then read git log --oneline -5."],
    ["BEGINNER","Take a long prompt and organize it into a role, goal, context, rules, and output."],
    ["BEGINNER","Create a JSON file with three favorite projects and check it with the JSON Helper."],
    ["BEGINNER+","Build a local counter with plus and minus buttons. Save the number in localStorage."],
    ["BEGINNER+","Write a project README with a goal, start instructions, features, and next step."],
    ["BEGINNER+","Build a search box that filters a list of five items as you type."],
    ["CREATIVE","Design a home page for an imaginary tool: one clear problem, a headline, and exactly three features."],
    ["CREATIVE","Invent a tiny tool that saves you one click every day. Sketch its first version in 30 minutes."]
  ];
  var lastMission = -1;
  $("#newMission").addEventListener("click", function () {
    var index = Math.floor(Math.random() * missions.length);
    if (missions.length > 1 && index === lastMission) index = (index + 1) % missions.length;
    lastMission = index;
    $("#missionLevel").textContent = missions[index][0];
    $("#missionText").textContent = missions[index][1];
  });

  // The prompt library is a small data file so all 20 prompts can also ship
  // as a readable Markdown collection in the downloadable pack.
  var promptSearch = $("#promptSearch");
  var promptRoot = $("#promptLibrary");
  if (promptRoot && window.LUNA_PROMPTS) {
    var prompts = window.LUNA_PROMPTS;
    var activeCategory = "All";
    function renderPromptLibrary() {
      var query = promptSearch.value.trim().toLowerCase();
      promptRoot.textContent = "";
      var matches = prompts.filter(function (prompt) {
        var matchesCategory = activeCategory === "All" || prompt.category === activeCategory;
        var searchable = [prompt.title, prompt.description, prompt.prompt, prompt.input, prompt.example, prompt.category].join(" ").toLowerCase();
        return matchesCategory && (!query || searchable.indexOf(query) !== -1);
      });
      matches.forEach(function (prompt) {
        var card = document.createElement("article");
        card.className = "prompt-card";
        var head = document.createElement("div");
        head.className = "prompt-card-head";
        var category = document.createElement("span");
        category.className = "prompt-category";
        category.textContent = prompt.category;
        head.appendChild(category);
        var title = document.createElement("h3");
        title.textContent = prompt.title;
        var description = document.createElement("p");
        description.textContent = prompt.description;
        var details = document.createElement("details");
        details.className = "prompt-details";
        var summary = document.createElement("summary");
        summary.textContent = "See the prompt and a worked example";
        details.appendChild(summary);
        var copyButton = document.createElement("button");
        copyButton.type = "button";
        copyButton.className = "copy-mini";
        copyButton.textContent = "Copy prompt";
        copyButton.addEventListener("click", function () { copyText(prompt.prompt); });
        details.appendChild(copyButton);
        var promptText = document.createElement("pre");
        promptText.className = "prompt-copy";
        promptText.textContent = prompt.prompt;
        details.appendChild(promptText);
        var example = document.createElement("div");
        example.className = "example-block";
        var inputLabel = document.createElement("strong");
        inputLabel.textContent = "Example input";
        var inputText = document.createElement("p");
        inputText.textContent = prompt.input;
        var answerLabel = document.createElement("strong");
        answerLabel.textContent = "Illustrative example";
        var answer = document.createElement("p");
        answer.textContent = prompt.example;
        example.appendChild(inputLabel);
        example.appendChild(inputText);
        example.appendChild(answerLabel);
        example.appendChild(answer);
        details.appendChild(example);
        card.appendChild(head);
        card.appendChild(title);
        card.appendChild(description);
        card.appendChild(details);
        promptRoot.appendChild(card);
      });
      $("#promptCount").textContent = "Showing " + matches.length + " of " + prompts.length + " prompts.";
      $("#promptEmpty").hidden = matches.length > 0;
    }
    promptSearch.addEventListener("input", renderPromptLibrary);
    $$(".prompt-filter").forEach(function (button) {
      button.addEventListener("click", function () {
        activeCategory = button.dataset.category;
        $$(".prompt-filter").forEach(function (other) {
          other.setAttribute("aria-pressed", String(other === button));
        });
        renderPromptLibrary();
      });
    });
    renderPromptLibrary();
  }

  // Let people mark the project walkthrough as they go; the checkboxes stay
  // private to this browser and can be reset at any time.
  var guideSteps = $$("[data-guide-step]");
  function loadGuide() {
    try {
      var saved = JSON.parse(store.get(KEYS.guide));
      return Array.isArray(saved) && saved.length === guideSteps.length && saved.every(function (item) { return typeof item === "boolean"; })
        ? saved : guideSteps.map(function () { return false; });
    } catch (e) { return guideSteps.map(function () { return false; }); }
  }
  var guideState = loadGuide();
  function renderGuide() {
    var complete = 0;
    guideSteps.forEach(function (step, index) {
      step.checked = guideState[index];
      if (guideState[index]) complete += 1;
    });
    $("#guideProgress").textContent = complete + " of " + guideSteps.length + " steps";
  }
  guideSteps.forEach(function (step, index) {
    step.addEventListener("change", function () {
      guideState[index] = step.checked;
      store.set(KEYS.guide, JSON.stringify(guideState));
      renderGuide();
    });
  });
  $("#resetGuide").addEventListener("click", function () {
    if (guideState.some(Boolean) && !window.confirm("Reset the walkthrough? Your saved progress will be cleared.")) return;
    guideState = guideSteps.map(function () { return false; });
    store.set(KEYS.guide, JSON.stringify(guideState));
    renderGuide();
    toast("Walkthrough progress reset.");
  });
  renderGuide();

  // A supporter name personalizes a local download; it is never sent anywhere.
  var supporterName = $("#supporterName");
  var savedName = store.get(KEYS.supporter);
  if (savedName) supporterName.value = savedName.slice(0, 60);
  function updateGreeting() {
    var name = supporterName.value.trim().replace(/[<>]/g, "");
    $("#thankYouGreeting").textContent = name ? "Dear " + name + "," : "Dear early explorer,";
    store.set(KEYS.supporter, name);
  }
  supporterName.addEventListener("input", updateGreeting);
  updateGreeting();
  $("#downloadNote").addEventListener("click", function () {
    var name = supporterName.value.trim().replace(/[<>]/g, "");
    var greeting = name ? "Dear " + name + "," : "Dear early explorer,";
    var note = greeting + "\n\nThank you for being here while the ideas are still small and the possibilities are wide open.\n\nI hope this little pack gives you a useful starting point, a moment of curiosity, and the confidence to make something of your own.\n\nYou don't have to build something big. Just start with something that matters to you.\n\nWith love,\nLuna ☾\n";
    var url = URL.createObjectURL(new Blob([note], {type:"text/plain;charset=utf-8"}));
    var link = document.createElement("a");
    link.href = url;
    link.download = "a-note-from-luna.txt";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    toast("Your note is ready to keep.");
  });
}());
